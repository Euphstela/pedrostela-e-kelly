letra = input("Digite uma letra: ").lower()

if letra in 'aeiou':
    print(f"{letra} é uma vogal.")
else:
    print(f"{letra} é uma consoante.")