jogada = input("Selecione uma jogada (touchdown, conversão, field goal, punt, kickoff): ").lower()

if jogada == "touchdown":
    print("Pontuação: 6 pontos")
elif jogada == "conversão":
    print("Pontuação: 1 ou 2 pontos")
elif jogada == "field goal":
    print("Pontuação: 3 pontos")
elif jogada == "punt":
    print("Pontuação: Nenhum ponto")
elif jogada == "kickoff":
    print("Pontuação: Nenhum ponto")
else:
    print("Jogada inválida.")