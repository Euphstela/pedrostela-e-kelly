numeros = []
for i in range(10):
    numero = int(input(f"Digite o {i+1}º número: "))
    numeros.append(numero)

print("Ordem inversa:", numeros[::-1])
print("Ordem correta:", numeros)