salario = float(input("Digite o salário mensal do funcionário: "))
tempo_servico = int(input("Digite o tempo de serviço em anos: "))

if tempo_servico >= 5:
    novo_salario = salario * 1.10 # Aumento de 10%
    print(f"O novo salário com bônus é: R${novo_salario:.2f}")
else:
    print(f"O salário permanece: R${salario:.2f}")